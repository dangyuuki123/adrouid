package com.example.sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {


    database datab ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        datab = new database(this , "event.sqlite" , null , 1);

        //tao bang
        datab.queryData(" CREATE TABLE IF NOT EXISTS event(Id INTEGER PRIMARY KEY AUTOINCREMENT, LP_label VARCHAR(50) , violate_time DATETIME DEFAULT CURRENT_TIMESTAMP ,vehicle_type TEXT CHECK( product_type('a','b','c')) NOT null DEFAULT 'a', color INTEGER )");
    }
}